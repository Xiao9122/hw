CREATE TABLE MP_Station(
    Station_ID int NOT NULL PRIMARY KEY,
    Station_Color VARCHAR(20) NOT NULL
);