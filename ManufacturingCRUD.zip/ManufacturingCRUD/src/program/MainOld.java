/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program;
import entity.*;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
/**
 *
 * @author Gokhan
 */
public class MainOld {

    /**
     * @param args the command line arguments
     */
    
    private static DAO stationDAO;
    private static DAO partDAO;
    
    public static void main(String[] args) {
        stationDAO = new StationDAO();
        partDAO = new PartDAO();
        
        Station station;
        Part part;
        
        Scanner input = new Scanner(System.in);
        Scanner sinput = new Scanner(System.in);
        Scanner binput = new Scanner(System.in); 
        int option = 0;
        while(option != 9) {
            printOptions();
            System.out.println("Enter the funtion number: ");
            option = input.nextInt();
            if (option == 1) {
                System.out.println("Creating a new Station\n"
                        + "Enter the station's id, and station color");
                station = new Station(input.nextInt(),sinput.nextLine());
                stationDAO.insert(station);
            } else if (option == 2) {
                System.out.println("Reading all Stations\n");
                printStations();
            } else if (option == 3) {
                System.out.println("Updating a Station\n"
                        + "Enter the station's id than the updated station color");
                station = new Station(input.nextInt(),sinput.nextLine());
                stationDAO.update(station);
            } else if (option == 4) {
                System.out.println("Deleting a Station\n"
                        + "Enter the station's id.");
                station = new Station(input.nextInt(), "");
                stationDAO.delete(station);
            }   // starting Part 
            if (option == 5) {
                System.out.println("Creating a new Part\n"
                        + "Enter the part's id, if repaired, station's id, and station date time. "
                        + "Datetime format must be "
                        + "2019-08-05 11:01:23.000");
                part = new Part(input.nextInt(),binput.nextBoolean(), sinput.nextInt(), sinput.nextLine());
                partDAO.insert(part);
            } else if (option == 6) {
                System.out.println("Reading all Parts\n");
                printParts();
            } else if (option == 7) {
                System.out.println("Updating a Part\n"
                        + "Enter the part's id than the updated if repaired, station's id, and station date time. "
                        + "Datetime format must be 2019-08-05 11:01:23.000");
                part = new Part(input.nextInt(),binput.nextBoolean(), sinput.nextInt(), sinput.nextLine());
                partDAO.update(part);
            } else if (option == 8) {
                System.out.println("Deleting a Part\n"
                        + "Enter the part's id.");
               part = new Part(input.nextInt(),false, -1, "");
                partDAO.delete(part);
            }
        }
        
//        addStation(1, "Yellow");
//        addStation(2, "Red");
//        printStations();
        
//        printStations();
//        station = new Station(1, "Orange");
//        stationDAO.update(station);
//        printStations();
//        
////        station = new Station(1, "Orange");
////        stationDAO.update(station);//Update John
////        station = new Station(2, "Alice", "Mira", "Drink");
////        stationDAO.insert(station);//Insert Alice
////        station = new Station(2, "Alice", "Smith", "Drink");
////        stationDAO.update(station);
////        station = new Station(3, "Sezen", "Aksu", "Combo");
////        stationDAO.insert(station);//Insert Sezen
//        printStations();


        
        
//        
//        addPart(85,true, 1, "2008-01-01 12:16:18.000");
//        addPart(99,false, 2, "2008-01-01 12:20:57.000");
//        addPart(105,false, 1, "2008-01-01 12:20:57.000");
//        printParts();

//        printParts();
//        part = new Part(105,false, 3, "2008-01-01 12:25:29.000");
//        partDAO.update(part);
//        printParts();
//        
//        printParts();
//        part = new Part(187,"Lydia", "Murray", 26, "2009-10-19 09:48:13.000");
//        partDAO.update(part);
//        printParts();
        
//        part = new Part(1, 2, "2021-02-23 08:48:11.556", "Hot Dog", 1);
//        partDAO.delete(part);//insert part 2

    }
    static void printOptions() {
        System.out.println("Station table CRUD funtions\n"
                + "1. Create\n"
                + "2. Read\n"
                + "3. Update\n"
                + "4. Delete\n"
                + "Part table CRUD funtions\n"
                + "5. Create\n"
                + "6. Read\n"
                + "7. Update\n"
                + "8. Delete\n"
                + "\n9. To Exit");
    }
    
    private static void addStation(int id, String station) {
        Station checkin;
        checkin = new Station(id, station);
        stationDAO.insert(checkin);
    }
    
    private static void addPart(int ID, boolean repair,int SID, String assembledDateTime) {
        Part part;
        part = new Part(ID, repair, SID, assembledDateTime);
        partDAO.insert(part);
    }
    
    static Station getStation(int id) {
        Optional<Station> checkin = stationDAO.get(id);
        return checkin.orElseGet(() -> new Station(-1, "Non-exist"));
    }
    
    static Part getPart(int id) {
        Optional<Part> part = partDAO.get(id);
        return part.orElseGet(() -> new Part(-1, false, -1, "Non-exist"));
    }
    
    
    static void printStations() {
        List<String> headers = stationDAO.getColumnNames();
        int numberCols = headers.size();
        //Print column names as header
        for (int i = 0; i < numberCols; i++) {
            String header = headers.get(i);
            System.out.printf("%25s", header);
        }
        System.out.println();
        //Print the results
        List<Station> stations = stationDAO.getAll();
        int numberRows = stations.size();
        for (int i = 0; i < numberRows; i++) {
            System.out.printf("%25s%25s", 
                    stations.get(i).getID(), 
                    stations.get(i).getStationColor());
            System.out.println();
        }
    }
    
    static void printParts() {
        List<String> headers = partDAO.getColumnNames();
        int numberCols = headers.size();
        //Print column names as header
        for (int i = 0; i < numberCols; i++) {
            String header = headers.get(i);
            System.out.printf("%25s", header);
        }
        System.out.println();
        //Print the results
        List<Part> parts = partDAO.getAll();
        int numberRows = parts.size();
        for (int i = 0; i < numberRows; i++) {
            System.out.printf("%25s%25s%25s%25s", parts.get(i).getID(), 
                    parts.get(i).isRepaired(), 
                    parts.get(i).getStationID(), 
                    parts.get(i).getDateTimeAssembled());
            System.out.println();
        }
    }
}
